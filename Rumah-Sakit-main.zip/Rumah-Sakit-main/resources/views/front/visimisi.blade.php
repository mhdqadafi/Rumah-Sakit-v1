@extends('front.layout.main_front')
@section('content')

<div class="container mt-5">
    <h1 class="mb-4">Visi & Misi</h1>

    <h4>Visi</h4>
    

    <h4 class="mt-4">Misi</h4>
    
</div>

@endsection