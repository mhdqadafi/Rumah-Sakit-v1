@extends('front.layout.main_front')
@section('content')

<div class="container mt-5">
    <h1 class="mb-4">Sambutan Pimpinan</h1>

    

    <h5 class="mt-4">Hormat kami,</h5>
    <p><strong>Nama Pimpinan</strong><br>Jabatan</p>
</div>

@endsection